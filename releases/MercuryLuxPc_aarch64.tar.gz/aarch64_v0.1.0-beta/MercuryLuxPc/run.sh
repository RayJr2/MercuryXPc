#!/bin/bash
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

# Setup runtime environment
export LD_LIBRARY_PATH="$SCRIPT_DIR/libs:$SCRIPT_DIR/platforms:$LD_LIBRARY_PATH"
export QT_QPA_PLATFORM_PLUGIN_PATH="$SCRIPT_DIR/platforms"
export QT_TLS_BACKEND_PLUGIN_PATH="$SCRIPT_DIR/tls"
export QT_QPA_PLATFORM="xcb"
unset LD_PRELOAD

# Launch app
"$SCRIPT_DIR/MercuryLuxPc" "$@"
