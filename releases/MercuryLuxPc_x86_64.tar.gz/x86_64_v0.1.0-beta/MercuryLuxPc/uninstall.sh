#!/bin/bash

APP_NAME="MercuryLuxPc"
INSTALL_DIR="$HOME/Applications/$APP_NAME"
DESKTOP_FILE="$HOME/.local/share/applications/${APP_NAME}.desktop"

echo "Removing application..."
rm -rf "$INSTALL_DIR"

echo "Removing desktop entry..."
rm -f "$DESKTOP_FILE"

update-desktop-database ~/.local/share/applications/ &>/dev/null

echo "$APP_NAME has been uninstalled."
